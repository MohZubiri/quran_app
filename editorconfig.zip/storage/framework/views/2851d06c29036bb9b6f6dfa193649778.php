<?php $__env->startSection('title', 'تعديل الدور'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0 text-gray-800">تعديل الدور: <?php echo e($role->display_name); ?></h1>
        <a href="<?php echo e(route('admin.roles.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-right ml-1"></i> العودة للأدوار
        </a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">بيانات الدور</h6>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.roles.update', $role)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">اسم الدور (بالإنجليزية)</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" name="name" value="<?php echo e(old('name', $role->name)); ?>" required dir="ltr" <?php echo e(in_array($role->name, ['admin', 'teacher', 'student']) ? 'readonly' : ''); ?>>
                            <small class="form-text text-muted">مثال: branch-manager, supervisor (استخدم الحروف الصغيرة والشرطات)</small>
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="display_name">الاسم المعروض (بالعربية)</label>
                            <input type="text" class="form-control <?php $__errorArgs = ['display_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="display_name" name="display_name" value="<?php echo e(old('display_name', $role->display_name)); ?>" required>
                            <small class="form-text text-muted">مثال: مدير فرع، مشرف</small>
                            <?php $__errorArgs = ['display_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">وصف الدور</label>
                    <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="description" name="description" rows="3"><?php echo e(old('description', $role->description)); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="form-group">
                    <label>الصلاحيات</label>
                    <div class="card">
                        <div class="card-body">
                            <?php $__empty_1 = true; $__currentLoopData = $permissionsByGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="mb-3">
                                    <h6 class="border-right-primary pr-2 mb-2"><?php echo e($group); ?></h6>
                                    <div class="row">
                                        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4 mb-2">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" class="custom-control-input" 
                                                           id="permission_<?php echo e($permission->id); ?>" 
                                                           name="permissions[]" 
                                                           value="<?php echo e($permission->id); ?>"
                                                           <?php echo e(in_array($permission->id, old('permissions', $rolePermissions)) ? 'checked' : ''); ?>>
                                                    <label class="custom-control-label" for="permission_<?php echo e($permission->id); ?>">
                                                        <?php echo e($permission->display_name); ?>

                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-muted mb-0">لا توجد صلاحيات مضافة حتى الآن</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save ml-1"></i> حفظ التغييرات
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Add select all checkbox for each permission group
        const permissionGroups = document.querySelectorAll('.mb-3');
        
        permissionGroups.forEach(function(group, index) {
            const checkboxes = group.querySelectorAll('input[type="checkbox"]');
            const heading = group.querySelector('h6');
            
            // Create select all checkbox
            const selectAllDiv = document.createElement('div');
            selectAllDiv.className = 'custom-control custom-checkbox d-inline-block ml-2';
            
            const selectAllInput = document.createElement('input');
            selectAllInput.type = 'checkbox';
            selectAllInput.className = 'custom-control-input';
            selectAllInput.id = `select_all_${index}`;
            
            const selectAllLabel = document.createElement('label');
            selectAllLabel.className = 'custom-control-label';
            selectAllLabel.htmlFor = `select_all_${index}`;
            selectAllLabel.textContent = 'تحديد الكل';
            
            selectAllDiv.appendChild(selectAllInput);
            selectAllDiv.appendChild(selectAllLabel);
            
            heading.appendChild(selectAllDiv);
            
            // Add event listener to select all checkbox
            selectAllInput.addEventListener('change', function() {
                checkboxes.forEach(function(checkbox) {
                    checkbox.checked = selectAllInput.checked;
                });
            });
            
            // Update select all checkbox when individual checkboxes change
            checkboxes.forEach(function(checkbox) {
                checkbox.addEventListener('change', function() {
                    const allChecked = Array.from(checkboxes).every(function(cb) {
                        return cb.checked;
                    });
                    
                    const anyChecked = Array.from(checkboxes).some(function(cb) {
                        return cb.checked;
                    });
                    
                    selectAllInput.checked = allChecked;
                    selectAllInput.indeterminate = anyChecked && !allChecked;
                });
            });
            
            // Initialize select all checkbox state
            const allChecked = Array.from(checkboxes).every(function(cb) {
                return cb.checked;
            });
            
            const anyChecked = Array.from(checkboxes).some(function(cb) {
                return cb.checked;
            });
            
            selectAllInput.checked = allChecked;
            selectAllInput.indeterminate = anyChecked && !allChecked;
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>
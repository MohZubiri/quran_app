<?php $__env->startSection('title', 'تفاصيل الطالب'); ?>

<?php $__env->startSection('styles'); ?>
<!-- Add any additional styles here -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('actions'); ?>
<div class="btn-group" role="group">
    <a href="<?php echo e(route('admin.students.index')); ?>" class="btn btn-sm btn-secondary">
        <i class="fas fa-arrow-right me-1"></i> العودة إلى قائمة الطلاب
    </a>
    <a href="<?php echo e(route('admin.students.edit', $student->id)); ?>" class="btn btn-sm btn-warning">
        <i class="fas fa-edit me-1"></i> تعديل بيانات الطالب
    </a>
    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">
        <i class="fas fa-trash me-1"></i> حذف الطالب
    </button>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">تأكيد الحذف</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
            </div>
            <div class="modal-body">
                هل أنت متأكد من رغبتك في حذف الطالب "<?php echo e($student->name); ?>"؟ هذا الإجراء لا يمكن التراجع عنه.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <form action="<?php echo e(route('admin.students.destroy', $student->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">حذف</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">معلومات الطالب</h5>
                    <?php if(!$student->user_id): ?>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createAccountModal">
                            <i class="fas fa-user-plus me-1"></i>
                            إنشاء حساب
                        </button>
                    <?php else: ?>
                        <span class="badge bg-success">
                            <i class="fas fa-check me-1"></i>
                            تم إنشاء الحساب
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <th style="width: 40%">الاسم الكامل</th>
                            <td><?php echo e($student->name); ?></td>
                        </tr>
                        <tr>
                            <th>تاريخ الميلاد</th>
                            <td><?php echo e($student->birth_date ? $student->birth_date->format('Y-m-d') : 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>العمر</th>
                            <td><?php echo e($student->birth_date ? $student->birth_date->age . ' سنة' : 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>الجنس</th>
                            <td><?php echo e($student->gender == 'male' ? 'ذكر' : 'أنثى'); ?></td>
                        </tr>
                        <tr>
                            <th>رقم الهاتف</th>
                            <td><?php echo e($student->phone ?? 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>البريد الإلكتروني</th>
                            <td><?php echo e($student->email ?? 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>العنوان</th>
                            <td><?php echo e($student->address ?? 'غير محدد'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-4">
    <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">إحصائيات الطالب</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6 mb-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">الحلقات</h6>
                                <p class="card-text display-6"><?php echo e($student->enrollments->count()); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card bg-success text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">نسبة الحضور</h6>
                                <p class="card-text display-6">
                                    <?php
                                        $attendanceCount = $student->attendance->count();
                                        $presentCount = $student->attendance->where('status', 'present')->count();
                                        $attendanceRate = $attendanceCount > 0 ? round(($presentCount / $attendanceCount) * 100) : 0;
                                    ?>
                                    <?php echo e($attendanceRate); ?>%
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card bg-info text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">التقييمات</h6>
                                <p class="card-text display-6"><?php echo e($student->grades->count()); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card bg-warning text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">متوسط الدرجات</h6>
                                <p class="card-text display-6">
                                    <?php
                                        $grades = $student->grades;
                                        $avgScore = $grades->count() > 0 ? round($grades->avg('grade')) : 0;
                                    ?>
                                    <?php echo e($avgScore); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">معلومات التسجيل</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <th style="width: 40%">الفرع</th>
                            <td><?php echo e($student->branch->name ?? 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>تاريخ التسجيل</th>
                            <td><?php echo e($student->created_at ? $student->created_at->format('Y-m-d') : 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>المستوى الحالي</th>
                            <td><?php echo e($student->current_level ?? 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>الحالة</th>
                            <td>
                                <?php if($student->status == 'active'): ?>
                                    <span class="badge bg-success">نشط</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">غير نشط</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        
       
    </div>
</div>

<?php if($student->initial_assessment): ?>
<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">التقييم الأولي</h5>
            </div>
            <div class="card-body">
                <p><?php echo e($student->initial_assessment); ?></p>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($student->notes): ?>
<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">ملاحظات إضافية</h5>
            </div>
            <div class="card-body">
                <p><?php echo e($student->notes); ?></p>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title">الحلقات المسجل فيها الطالب</h5>
                <a href="<?php echo e(route('admin.enrollments.create', ['student_id' => $student->id])); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> تسجيل في حلقة جديدة
                </a>
            </div>
            <div class="card-body">
                <?php if($student->enrollments->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الحلقة</th>
                                <th>المادة</th>
                                <th>المعلم</th>
                                <th>الجدول</th>
                                <th>تاريخ التسجيل</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $student->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($enrollment->group->name ?? 'حلقة ' . $enrollment->group_id); ?></td>
                                <td><?php echo e($enrollment->group->subject->name ?? 'غير محدد'); ?></td>
                                <td><?php echo e($enrollment->group->teacher->name ?? ''); ?> </td>
                                <td><?php echo e($enrollment->group->schedule ?? 'غير محدد'); ?></td>
                                <td><?php echo e($enrollment->enrollment_date ? $enrollment->enrollment_date->format('Y-m-d') : 'غير محدد'); ?></td>
                                <td>
                                    <?php if($enrollment->status == 'active'): ?>
                                        <span class="badge bg-success">نشط</span>
                                    <?php elseif($enrollment->status == 'completed'): ?>
                                        <span class="badge bg-info">مكتمل</span>
                                    <?php elseif($enrollment->status == 'dropped'): ?>
                                        <span class="badge bg-danger">منسحب</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($enrollment->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.groups.show', $enrollment->group_id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.enrollments.edit', $enrollment->id)); ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    الطالب غير مسجل في أي حلقات حتى الآن.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title">سجل الحضور الأخير</h5>
                <a href="<?php echo e(route('admin.attendance.create', ['student_id' => $student->id])); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> تسجيل حضور جديد
                </a>
            </div>
            <div class="card-body">
                <?php if($student->attendance()->latest()->take(5)->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>التاريخ</th>
                                <th>الحلقة</th>
                                <th>الحالة</th>
                                <th>ملاحظات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $student->attendance()->latest()->take(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($attendance->date->format('Y-m-d')); ?></td>
                                <td><?php echo e($attendance->group->name ?? 'حلقة ' . $attendance->group_id); ?></td>
                                <td>
                                    <?php if($attendance->status == 'present'): ?>
                                        <span class="badge bg-success">حاضر</span>
                                    <?php elseif($attendance->status == 'absent'): ?>
                                        <span class="badge bg-danger">غائب</span>
                                    <?php elseif($attendance->status == 'late'): ?>
                                        <span class="badge bg-warning">متأخر</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($attendance->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($attendance->notes ?? 'لا توجد ملاحظات'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <a href="<?php echo e(route('admin.attendance.index', ['student_id' => $student->id])); ?>" class="btn btn-sm btn-outline-primary">
                        عرض سجل الحضور الكامل
                    </a>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    لا يوجد سجل حضور لهذا الطالب حتى الآن.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title">name</h5>
                <a href="<?php echo e(route('admin.grades.create', ['student_id' => $student->id])); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> إضافة تقييم جديد
                </a>
            </div>
            <div class="card-body">
                <?php if($student->grades()->latest()->take(5)->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>التاريخ</th>
                                <th>المادة</th>
                                <th>المعلم</th>
                                <th>الدرجة</th>
                                <th>ملاحظات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $student->grades()->latest()->take(4)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($grade->date->format('Y-m-d')); ?></td>
                                <td><?php echo e($grade->subject->name ?? 'غير محدد'); ?></td>
                                <td> <?php echo e($grade->teacher->name ?? 'غير محدد'); ?></td>
                                <td>
                                    <span class="badge <?php echo e($grade->grade >= 90 ? 'bg-success' : ($grade->grade >= 70 ? 'bg-info' : ($grade->grade >= 50 ? 'bg-warning' : 'bg-danger'))); ?>">
                                        <?php echo e($grade->grade); ?>

                                    </span>
                                </td>
                                <td><?php echo e(Str::limit($grade->notes, 30) ?? 'لا توجد ملاحظات'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <a href="<?php echo e(route('admin.grades.index', ['student_id' => $student->id])); ?>" class="btn btn-sm btn-outline-primary">
                        عرض سجل التقييمات الكامل
                    </a>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    لا توجد تقييمات لهذا الطالب حتى الآن.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<!-- Create Account Modal -->
<div class="modal fade" id="createAccountModal" tabindex="-1" aria-labelledby="createAccountModalLabel" aria-hidden="true" data-bs-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.students.create-account', $student->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="createAccountModalLabel">إنشاء حساب للطالب</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="password" class="form-label">كلمة المرور</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="password_confirmation" class="form-label">تأكيد كلمة المرور</label>
                        <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                    <button type="submit" class="btn btn-primary">إنشاء الحساب</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all modals
    var modals = document.querySelectorAll('.modal');
    modals.forEach(function(modal) {
        new bootstrap.Modal(modal);
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/admin/students/show.blade.php ENDPATH**/ ?>
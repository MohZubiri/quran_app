<?php $__env->startSection('title', 'سجل الحضور'); ?>

<?php $__env->startSection('actions'); ?>
<div class="btn-group" role="group">
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-attendance')): ?>
    <a href="<?php echo e(route('admin.attendance.create')); ?>" class="btn btn-sm btn-primary">
        <i class="fas fa-plus-circle me-1"></i> تسجيل حضور جديد
    </a>
    <?php endif; ?>
    <?php if(request()->filled('group_id')): ?>
    <a href="<?php echo e(route('admin.groups.show', request()->group_id)); ?>" class="btn btn-sm btn-secondary">
        <i class="fas fa-arrow-right me-1"></i> العودة إلى الحلقة
    </a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">سجل الحضور</h5>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-attendance')): ?>
        <a href="<?php echo e(route('admin.attendance.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> تسجيل حضور جديد
        </a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.attendance.index')); ?>" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="branch_id" class="form-label">الفرع</label>
                    <select class="form-select" id="branch_id" name="branch_id" required>
                        <option value="">جميع الفروع</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>" <?php echo e(request('branch_id') == $branch->id ? 'selected' : ''); ?>><?php echo e($branch->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label for="group_id" class="form-label">الحلقة</label>
                    <select class="form-select" id="group_id" name="group_id">
                        <option value="">جميع الحلقات</option>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>" <?php echo e(request('group_id') == $group->id ? 'selected' : ''); ?>><?php echo e($group->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label for="student_id" class="form-label">الطالب</label>
                    <select class="form-select" id="student_id" name="student_id">
                        <option value="">جميع الطلاب</option>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($student->id); ?>" <?php echo e(request('student_id') == $student->id ? 'selected' : ''); ?>><?php echo e($student->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label for="status" class="form-label">الحالة</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">جميع الحالات</option>
                        <option value="present" <?php echo e(request('status') == 'present' ? 'selected' : ''); ?>>حاضر</option>
                        <option value="absent" <?php echo e(request('status') == 'absent' ? 'selected' : ''); ?>>غائب</option>
                        <option value="late" <?php echo e(request('status') == 'late' ? 'selected' : ''); ?>>متأخر</option>
                        <option value="excused" <?php echo e(request('status') == 'excused' ? 'selected' : ''); ?>>معذور</option>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label for="date_from" class="form-label">من تاريخ</label>
                    <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo e(request('date_from')); ?>">
                </div>
                
                <div class="col-md-3">
                    <label for="date_to" class="form-label">إلى تاريخ</label>
                    <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo e(request('date_to')); ?>">
                </div>
                
                <div class="col-md-6 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary me-2">
                        <i class="fas fa-search me-1"></i> بحث
                    </button>
                    <a href="<?php echo e(route('admin.attendance.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-redo me-1"></i> إعادة تعيين
                    </a>
                </div>
            </div>
        </form>

        <?php if($attendance->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>التاريخ</th>
                        <th>الطالب</th>
                        <th>الحلقة</th>
                        <th>المعلم</th>
                        <th>الحالة</th>
                        <th>ملاحظات</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $attendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration + ($attendance->perPage() * ($attendance->currentPage() - 1))); ?></td>
                        <td><?php echo e($record->date->format('Y-m-d')); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-students')): ?>
                            <a href="<?php echo e(route('admin.students.show', $record->student_id)); ?>">
                                <?php echo e($record->student->name); ?> 
                            </a>
                            <?php else: ?>
                                <?php echo e($record->student->name); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-groups')): ?>
                            <a href="<?php echo e(route('admin.groups.show', $record->group_id)); ?>">
                                <?php echo e($record->group->name); ?>

                            </a>
                            <?php else: ?>
                                <?php echo e($record->group->name); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-teachers')): ?>
                            <a href="<?php echo e(route('admin.teachers.show', $record->teacher_id)); ?>">
                                <?php echo e($record->teacher->name); ?>

                            </a>
                            <?php else: ?>
                                <?php echo e($record->teacher->name); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($record->status == 'present'): ?>
                                <span class="badge bg-success">حاضر</span>
                            <?php elseif($record->status == 'absent'): ?>
                                <span class="badge bg-danger">غائب</span>
                            <?php elseif($record->status == 'late'): ?>
                                <span class="badge bg-warning">متأخر</span>
                            <?php elseif($record->status == 'excused'): ?>
                                <span class="badge bg-info">معذور</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e(Str::limit($record->notes, 30)); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-attendance')): ?>
                                <a href="<?php echo e(route('admin.attendance.edit', $record->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-attendance')): ?>
                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($record->id); ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Delete Modal -->
                            <div class="modal fade" id="deleteModal<?php echo e($record->id); ?>" tabindex="-1" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">تأكيد الحذف</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                        </div>
                                        <div class="modal-body">
                                            هل أنت متأكد من رغبتك في حذف سجل حضور الطالب "<?php echo e($record->student->name); ?> " بتاريخ <?php echo e($record->date->format('Y-m-d')); ?>؟
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                            <form action="<?php echo e(route('admin.attendance.destroy', $record->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">حذف</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($attendance->links()); ?>

        </div>
        
        <?php else: ?>
        <div class="alert alert-info">
            لا يوجد سجلات حضور حتى الآن
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Attendance Statistics -->
<div class="card mt-4">
    <div class="card-header">
        <h5 class="card-title mb-0">إحصائيات الحضور</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>الحالة</th>
                                <th>العدد</th>
                                <th>النسبة المئوية</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><span class="badge bg-success">حاضر</span></td>
                                <td><?php echo e($stats['by_status']['present']['count']); ?></td>
                                <td><?php echo e($stats['by_status']['present']['percentage']); ?>%</td>
                            </tr>
                            <tr>
                                <td><span class="badge bg-danger">غائب</span></td>
                                <td><?php echo e($stats['by_status']['absent']['count']); ?></td>
                                <td><?php echo e($stats['by_status']['absent']['percentage']); ?>%</td>
                            </tr>
                            <tr>
                                <td><span class="badge bg-warning">متأخر</span></td>
                                <td><?php echo e($stats['by_status']['late']['count']); ?></td>
                                <td><?php echo e($stats['by_status']['late']['percentage']); ?>%</td>
                            </tr>
                            <tr>
                                <td><span class="badge bg-info">معذور</span></td>
                                <td><?php echo e($stats['by_status']['excused']['count']); ?></td>
                                <td><?php echo e($stats['by_status']['excused']['percentage']); ?>%</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr class="table-dark">
                                <td>المجموع</td>
                                <td><?php echo e($stats['total']); ?></td>
                                <td>100%</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // تحديث قوائم الحلقات والطلاب عند تغيير الفرع
    document.getElementById('branch_id').addEventListener('change', function() {
        const branchId = this.value;
        
        // يمكن إضافة كود Ajax هنا لتحديث قائمة الحلقات والطلاب بناءً على الفرع المختار
    });
    
    // تحديث قائمة الطلاب عند تغيير الحلقة
    document.getElementById('group_id').addEventListener('change', function() {
        const groupId = this.value;
        
        // يمكن إضافة كود Ajax هنا لتحديث قائمة الطلاب بناءً على الحلقة المختارة
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/softbszs/quran.softnube.site/resources/views/admin/attendance/index.blade.php ENDPATH**/ ?>
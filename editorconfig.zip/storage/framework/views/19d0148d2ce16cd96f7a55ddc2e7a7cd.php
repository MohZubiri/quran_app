<?php $__env->startSection('title', 'إدارة المواد الدراسية'); ?>

<?php $__env->startSection('actions'); ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-subjects')): ?>
    <a href="<?php echo e(route('admin.subjects.create')); ?>" class="btn btn-sm btn-primary">
        <i class="fas fa-plus-circle me-1"></i> إضافة مادة جديدة
    </a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title">قائمة المواد الدراسية</h5>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-subjects')): ?>
        <a href="<?php echo e(route('admin.subjects.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> إضافة مادة جديدة
        </a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <div class="mb-3">
            <form action="<?php echo e(route('admin.subjects.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-3">
                    <select name="branch_id" class="form-select">
                        <option value="">-- جميع الفروع --</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>" <?php echo e(request('branch_id') == $branch->id ? 'selected' : ''); ?>><?php echo e($branch->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="بحث باسم المادة" value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary">
                        <i class="fas fa-search me-1"></i> بحث
                    </button>
                </div>
            </form>
        </div>

        <?php if(count($subjects) > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>اسم المادة</th>
                        <th>الوصف</th>
                        <th>الفرع</th>
                        <th>عدد الحلقات</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($subject->name); ?></td>
                        <td><?php echo e(Str::limit($subject->description, 50) ?? 'لا يوجد وصف'); ?></td>
                        <td><?php echo e($subject->branch->name ?? 'غير محدد'); ?></td>
                        <td><?php echo e($subject->groups->count()); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-subjects')): ?>
                                <a href="<?php echo e(route('admin.subjects.show', $subject->id)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-subjects')): ?>
                                <a href="<?php echo e(route('admin.subjects.edit', $subject->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-subjects')): ?>
                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($subject->id); ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Delete Modal -->
                            <div class="modal fade" id="deleteModal<?php echo e($subject->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($subject->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteModalLabel<?php echo e($subject->id); ?>">تأكيد الحذف</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                        </div>
                                        <div class="modal-body">
                                            هل أنت متأكد من رغبتك في حذف المادة "<?php echo e($subject->name); ?>"؟ هذا الإجراء لا يمكن التراجع عنه.
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                            <form action="<?php echo e(route('admin.subjects.destroy', $subject->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">حذف</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($subjects->links()); ?>

        </div>
        <?php else: ?>
        <div class="alert alert-info">
            لا توجد مواد دراسية مضافة حتى الآن. <a href="<?php echo e(route('admin.subjects.create')); ?>">إضافة مادة جديدة</a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/admin/subjects/index.blade.php ENDPATH**/ ?>
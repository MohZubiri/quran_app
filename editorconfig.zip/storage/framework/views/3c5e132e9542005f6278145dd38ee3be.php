<?php $__env->startSection('title', 'إدارة الحلقات'); ?>

<?php $__env->startSection('actions'); ?>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-groups')): ?>
<a href="<?php echo e(route('admin.groups.create')); ?>" class="btn btn-sm btn-primary">
    <i class="fas fa-plus-circle me-1"></i> إضافة حلقة جديدة
</a>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">قائمة الحلقات</h5>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-groups')): ?>
        <a href="<?php echo e(route('admin.groups.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> إضافة حلقة جديدة
        </a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <div class="mb-3">
            <form action="<?php echo e(route('admin.groups.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-3">
                    <select name="branch_id" class="form-select">
                        <option value="">-- جميع الفروع --</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>" <?php echo e(request('branch_id') == $branch->id ? 'selected' : ''); ?>><?php echo e($branch->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="subject_id" class="form-select">
                        <option value="">-- جميع المواد --</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subject->id); ?>" <?php echo e(request('subject_id') == $subject->id ? 'selected' : ''); ?>><?php echo e($subject->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="teacher_id" class="form-select">
                        <option value="">-- جميع المعلمين --</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher->id); ?>" <?php echo e(request('teacher_id') == $teacher->id ? 'selected' : ''); ?>><?php echo e($teacher->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">-- جميع الحالات --</option>
                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>نشط</option>
                        <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>مكتمل</option>
                        <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>ملغي</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="بحث باسم الحلقة" value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-secondary">
                        <i class="fas fa-search me-1"></i> بحث
                    </button>
                </div>
            </form>
        </div>

        <?php if(count($groups) > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>اسم الحلقة</th>
                        <th>المادة</th>
                        <th>المعلم</th>
                        <th>الفرع</th>
                        <th>الجدول</th>
                        <th>عدد الطلاب</th>
                        <th>الحالة</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($group->name); ?></td>
                        <td><?php echo e($group->subject->name ?? 'غير محدد'); ?></td>
                        <td><?php echo e($group->teacher->name ?? ''); ?> </td>
                        <td><?php echo e($group->branch->name ?? 'غير محدد'); ?></td>
                        <td><?php echo e($group->schedule ?? 'غير محدد'); ?></td>
                        <td><?php echo e($group->enrollments->count()); ?></td>
                        <td>
                            <?php if($group->status == 'active'): ?>
                                <span class="badge bg-success">نشط</span>
                            <?php elseif($group->status == 'completed'): ?>
                                <span class="badge bg-info">مكتمل</span>
                            <?php elseif($group->status == 'cancelled'): ?>
                                <span class="badge bg-danger">ملغي</span>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e($group->status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-groups')): ?>
                                <a href="<?php echo e(route('admin.groups.show', $group->id)); ?>" class="btn btn-sm btn-info">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-groups')): ?>
                                <a href="<?php echo e(route('admin.groups.edit', $group->id)); ?>" class="btn btn-sm btn-warning">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-groups')): ?>
                                <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($group->id); ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Delete Modal -->
                            <div class="modal fade" id="deleteModal<?php echo e($group->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($group->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteModalLabel<?php echo e($group->id); ?>">تأكيد الحذف</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                        </div>
                                        <div class="modal-body">
                                            هل أنت متأكد من رغبتك في حذف الحلقة "<?php echo e($group->name); ?>"؟ هذا الإجراء لا يمكن التراجع عنه.
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                            <form action="<?php echo e(route('admin.groups.destroy', $group->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">حذف</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($groups->links()); ?>

        </div>
        <?php else: ?>
        <div class="alert alert-info">
            لا توجد حلقات مضافة حتى الآن. <a href="<?php echo e(route('admin.groups.create')); ?>">إضافة حلقة جديدة</a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/softbszs/quran.softnube.site/resources/views/admin/groups/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'إدارة الفروع'); ?>

<?php $__env->startSection('actions'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">قائمة الفروع</h5>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-branches')): ?>
        <a href="<?php echo e(route('admin.branches.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> إضافة فرع جديد
        </a>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if(count($branches) > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>اسم الفرع</th>
                        <th>العنوان</th>
                        <th>رقم الهاتف</th>
                        <th>البريد الإلكتروني</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($branch->name); ?></td>
                        <td><?php echo e($branch->address ?? 'غير محدد'); ?></td>
                        <td><?php echo e(($branch->phone==null)? $branch->manager_phone :'غير محدد'); ?></td>
                        <td><?php echo e($branch->email ?? 'غير محدد'); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-branches')): ?>
                            <a href="<?php echo e(route('admin.branches.show', $branch->id)); ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-eye"></i>
                            </a>
                            <?php endif; ?>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-branches')): ?>
                            <a href="<?php echo e(route('admin.branches.edit', $branch->id)); ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php endif; ?>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-branches')): ?>
                            <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo e($branch->id); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                            <?php endif; ?>
                            
                            <!-- Delete Modal -->
                            <div class="modal fade" id="deleteModal<?php echo e($branch->id); ?>" tabindex="-1" aria-labelledby="deleteModalLabel<?php echo e($branch->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="deleteModalLabel<?php echo e($branch->id); ?>">تأكيد الحذف</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                        </div>
                                        <div class="modal-body">
                                            هل أنت متأكد من رغبتك في حذف فرع "<?php echo e($branch->name); ?>"؟ هذا الإجراء لا يمكن التراجع عنه.
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                            <form action="<?php echo e(route('admin.branches.destroy', $branch->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">حذف</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="alert alert-info">
            لا توجد فروع مضافة حتى الآن. <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-branches')): ?><a href="<?php echo e(route('admin.branches.create')); ?>">إضافة فرع جديد</a><?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/admin/branches/index.blade.php ENDPATH**/ ?>
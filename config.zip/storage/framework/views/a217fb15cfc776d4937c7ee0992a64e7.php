<?php $__env->startSection('title', 'لوحة التحكم'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <h1 class="mb-4">لوحة التحكم</h1>
    </div>
</div>

<div class="row">
    <!-- Student Info Card -->
    <div class="col-md-4 mb-4">
        <div class="card h-100">
            <div class="card-header bg-gradient-primary">
                <h5 class="mb-0">معلومات الطالب</h5>
            </div>
            <div class="card-body text-center">
                <div class="avatar-circle">
                    <i class="fas fa-user"></i>
                </div>
                <h4><?php echo e($student->name); ?></h4>
                <p class="text-muted"><?php echo e($student->group->name ?? 'غير مسجل في مجموعة'); ?></p>
                <p class="text-muted"><?php echo e($student->branch->name ?? 'غير مسجل في فرع'); ?></p>
                <div class="mt-3">
                    <p><i class="fas fa-calendar-alt me-2"></i> تاريخ الانضمام: <?php echo e($student->created_at->format('Y-m-d')); ?></p>
                    <p><i class="fas fa-book me-2"></i> المستوى الحالي: <?php echo e($student->current_level); ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Attendance Card -->
    <div class="col-md-8 mb-4">
        <div class="card h-100">
            <div class="card-header bg-gradient-info">
                <h5 class="mb-0">سجل الحضور</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>التاريخ</th>
                                <th>الحالة</th>
                                <th>المجموعة</th>
                                <th>المعلم</th>
                                <th>الملاحظات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentAttendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($record->date->format('Y-m-d')); ?></td>
                                    <td>
                                        <?php if($record->status == 'present'): ?>
                                            <span class="badge bg-success">حاضر</span>
                                        <?php elseif($record->status == 'absent'): ?>
                                            <span class="badge bg-danger">غائب</span>
                                        <?php elseif($record->status == 'late'): ?>
                                            <span class="badge bg-warning">متأخر</span>
                                        <?php elseif($record->status == 'excused'): ?>
                                            <span class="badge bg-info">معذور</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($record->group->name); ?></td>
                                    <td><?php echo e($record->teacher->name); ?></td>
                                    <td><?php echo e($record->notes); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center">لا توجد سجلات حضور</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Grades Table -->
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">قائمة التقييمات</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>المجموعة</th>
                                <th>الإنجاز</th>
                                <th>السلوك</th>
                                <th>الحضور</th>
                                <th>المظهر</th>
                                <th>التاريخ</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentGrades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dayGrade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($student->group->name); ?></td>
                                <td>
                                    <?php if(isset($dayGrade['grades']['achievement'])): ?>
                                        <?php if($dayGrade['grades']['achievement']->grade >= 90): ?>
                                            <span class="badge bg-success"><?php echo e($dayGrade['grades']['achievement']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['achievement']->grade >= 80): ?>
                                            <span class="badge bg-info"><?php echo e($dayGrade['grades']['achievement']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['achievement']->grade >= 70): ?>
                                            <span class="badge bg-primary"><?php echo e($dayGrade['grades']['achievement']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['achievement']->grade >= 60): ?>
                                            <span class="badge bg-warning"><?php echo e($dayGrade['grades']['achievement']->grade); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><?php echo e($dayGrade['grades']['achievement']->grade); ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(isset($dayGrade['grades']['behavior'])): ?>
                                        <?php if($dayGrade['grades']['behavior']->grade >= 90): ?>
                                            <span class="badge bg-success"><?php echo e($dayGrade['grades']['behavior']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['behavior']->grade >= 80): ?>
                                            <span class="badge bg-info"><?php echo e($dayGrade['grades']['behavior']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['behavior']->grade >= 70): ?>
                                            <span class="badge bg-primary"><?php echo e($dayGrade['grades']['behavior']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['behavior']->grade >= 60): ?>
                                            <span class="badge bg-warning"><?php echo e($dayGrade['grades']['behavior']->grade); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><?php echo e($dayGrade['grades']['behavior']->grade); ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(isset($dayGrade['grades']['attendance'])): ?>
                                        <?php if($dayGrade['grades']['attendance']->grade >= 90): ?>
                                            <span class="badge bg-success"><?php echo e($dayGrade['grades']['attendance']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['attendance']->grade >= 80): ?>
                                            <span class="badge bg-info"><?php echo e($dayGrade['grades']['attendance']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['attendance']->grade >= 70): ?>
                                            <span class="badge bg-primary"><?php echo e($dayGrade['grades']['attendance']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['attendance']->grade >= 60): ?>
                                            <span class="badge bg-warning"><?php echo e($dayGrade['grades']['attendance']->grade); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><?php echo e($dayGrade['grades']['attendance']->grade); ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(isset($dayGrade['grades']['appearance'])): ?>
                                        <?php if($dayGrade['grades']['appearance']->grade >= 90): ?>
                                            <span class="badge bg-success"><?php echo e($dayGrade['grades']['appearance']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['appearance']->grade >= 80): ?>
                                            <span class="badge bg-info"><?php echo e($dayGrade['grades']['appearance']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['appearance']->grade >= 70): ?>
                                            <span class="badge bg-primary"><?php echo e($dayGrade['grades']['appearance']->grade); ?></span>
                                        <?php elseif($dayGrade['grades']['appearance']->grade >= 60): ?>
                                            <span class="badge bg-warning"><?php echo e($dayGrade['grades']['appearance']->grade); ?></span>
                                        <?php else: ?>
                                            <span class="badge bg-danger"><?php echo e($dayGrade['grades']['appearance']->grade); ?></span>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($dayGrade['date']); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">لا توجد تقييمات</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($recentGrades->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/student/dashboard.blade.php ENDPATH**/ ?>
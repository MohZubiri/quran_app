<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <h2 class="mb-4">إدارة التسجيلات</h2>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-enrollments')): ?>
            <a href="<?php echo e(route('admin.enrollments.create')); ?>" class="btn btn-primary mb-3">
                <i class="fas fa-plus"></i> إضافة تسجيل جديد
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('admin.enrollments.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-3">
                    <label for="branch_id" class="form-label">الفرع</label>
                    <select class="form-select" id="branch_id" name="branch_id">
                        <option value="">كل الفروع</option>
                        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($branch->id); ?>" <?php echo e(request('branch_id') == $branch->id ? 'selected' : ''); ?>>
                                <?php echo e($branch->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                
                <div class="col-md-3">
                    <label for="group_id" class="form-label">المجموعة</label>
                    <select class="form-select" id="group_id" name="group_id">
                        <option value="">كل المجموعات</option>
                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($group->id); ?>" <?php echo e(request('group_id') == $group->id ? 'selected' : ''); ?>>
                                <?php echo e($group->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="status" class="form-label">الحالة</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">كل الحالات</option>
                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>نشط</option>
                        <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>غير نشط</option>
                    </select>
                </div>

                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> بحث
                    </button>
                    <a href="<?php echo e(route('admin.enrollments.index')); ?>" class="btn btn-secondary ms-2">
                        <i class="fas fa-redo"></i> إعادة تعيين
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Enrollments List -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">قائمة التسجيلات</h5>
        </div>
        <div class="card-body">
            <?php if($enrollments->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>الطالب</th>
                                <th>المجموعة</th>
                                <th>الفرع</th>
                                <th>تاريخ التسجيل</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration + ($enrollments->perPage() * ($enrollments->currentPage() - 1))); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-students')): ?>
                                        <a href="<?php echo e(route('admin.students.show', $enrollment->student_id)); ?>">
                                            <?php echo e($enrollment->student->name); ?> 
                                        </a>
                                        <?php else: ?>
                                            <?php echo e($enrollment->student->name); ?> 
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-groups')): ?>
                                        <a href="<?php echo e(route('admin.groups.show', $enrollment->group_id)); ?>">
                                            <?php echo e($enrollment->group->name); ?>

                                        </a>
                                        <?php else: ?>
                                            <?php echo e($enrollment->group->name); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($enrollment->group->branch->name); ?></td>
                                    <td><?php echo e($enrollment->created_at->format('Y-m-d')); ?></td>
                                    <td>
                                        <?php if($enrollment->status == 'active'): ?>
                                            <span class="badge bg-success">نشط</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">غير نشط</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                           
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-enrollments')): ?>
                                            <a href="<?php echo e(route('admin.enrollments.edit', $enrollment->id)); ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php endif; ?>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-enrollments')): ?>
                                            <form action="<?php echo e(route('admin.enrollments.destroy', $enrollment->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من حذف هذا التسجيل؟');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($enrollments->links()); ?>

                </div>
            <?php else: ?>
                <div class="alert alert-info">
                    لا يوجد تسجيلات حتى الآن
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Statistics -->
    <div class="card mt-4">
        <div class="card-header">
            <h5 class="card-title mb-0">إحصائيات التسجيل</h5>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>الحالة</th>
                                    <th>العدد</th>
                                    <th>النسبة المئوية</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><span class="badge bg-success">نشط</span></td>
                                    <td><?php echo e($stats['by_status']['active']['count']); ?></td>
                                    <td><?php echo e($stats['by_status']['active']['percentage']); ?>%</td>
                                </tr>
                                <tr>
                                    <td><span class="badge bg-danger">غير نشط</span></td>
                                    <td><?php echo e($stats['by_status']['inactive']['count']); ?></td>
                                    <td><?php echo e($stats['by_status']['inactive']['percentage']); ?>%</td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr class="table-dark">
                                    <td>المجموع</td>
                                    <td><?php echo e($stats['total']); ?></td>
                                    <td>100%</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/admin/enrollments/index.blade.php ENDPATH**/ ?>
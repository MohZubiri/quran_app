<?php $__env->startSection('title', 'تفاصيل الحلقة'); ?>

<?php $__env->startSection('actions'); ?>
<div class="btn-group" role="group">
    <a href="<?php echo e(route('admin.groups.index')); ?>" class="btn btn-sm btn-secondary">
        <i class="fas fa-arrow-right me-1"></i> العودة إلى قائمة الحلقات
    </a>
    <a href="<?php echo e(route('admin.groups.edit', $group->id)); ?>" class="btn btn-sm btn-warning">
        <i class="fas fa-edit me-1"></i> تعديل الحلقة
    </a>
    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">
        <i class="fas fa-trash me-1"></i> حذف الحلقة
    </button>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">تأكيد الحذف</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
            </div>
            <div class="modal-body">
                هل أنت متأكد من رغبتك في حذف الحلقة "<?php echo e($group->name); ?>"؟ هذا الإجراء لا يمكن التراجع عنه.
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <form action="<?php echo e(route('admin.groups.destroy', $group->id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">حذف</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">معلومات الحلقة</h5>
            </div>
            <div class="card-body">
                <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <th style="width: 30%">اسم الحلقة</th>
                            <td><?php echo e($group->name); ?></td>
                        </tr>
                        <tr>
                            <th>المادة الدراسية</th>
                            <td>
                                <?php if($group->subject): ?>
                                    <a href="<?php echo e(route('admin.subjects.show', $group->subject_id)); ?>"><?php echo e($group->subject->name); ?></a>
                                <?php else: ?>
                                    غير محدد
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>المعلم</th>
                            <td>
                                <?php if($group->teacher): ?>
                                    <a href="<?php echo e(route('admin.teachers.show', $group->teacher_id)); ?>"><?php echo e($group->teacher->name); ?></a>
                                <?php else: ?>
                                    غير محدد
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>الفرع</th>
                            <td>
                                <?php if($group->branch): ?>
                                    <a href="<?php echo e(route('admin.branches.show', $group->branch_id)); ?>"><?php echo e($group->branch->name); ?></a>
                                <?php else: ?>
                                    غير محدد
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>جدول الحلقة</th>
                            <td><?php echo e($group->schedule ?? 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>مكان الحلقة</th>
                            <td><?php echo e($group->location ?? 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>تاريخ البدء</th>
                            <td><?php echo e($group->start_date ? $group->start_date->format('Y-m-d') : 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>تاريخ الانتهاء</th>
                            <td><?php echo e($group->end_date ? $group->end_date->format('Y-m-d') : 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>السعة القصوى</th>
                            <td><?php echo e($group->capacity ?? 'غير محدد'); ?></td>
                        </tr>
                        <tr>
                            <th>عدد الطلاب المسجلين</th>
                            <td><?php echo e($group->enrollments->count()); ?></td>
                        </tr>
                        <tr>
                            <th>الحالة</th>
                            <td>
                                <?php if($group->status == 'active'): ?>
                                    <span class="badge bg-success">نشط</span>
                                <?php elseif($group->status == 'completed'): ?>
                                    <span class="badge bg-info">مكتمل</span>
                                <?php elseif($group->status == 'cancelled'): ?>
                                    <span class="badge bg-danger">ملغي</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($group->status); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if($group->description || $group->notes): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">تفاصيل إضافية</h5>
            </div>
            <div class="card-body">
                <?php if($group->description): ?>
                <div class="mb-4">
                    <h6 class="fw-bold">وصف الحلقة:</h6>
                    <p><?php echo e($group->description); ?></p>
                </div>
                <?php endif; ?>

                <?php if($group->notes): ?>
                <div>
                    <h6 class="fw-bold">ملاحظات إضافية:</h6>
                    <p><?php echo e($group->notes); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title">الطلاب المسجلين في الحلقة</h5>
                <a href="<?php echo e(route('admin.enrollments.create', ['group_id' => $group->id])); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> إضافة طالب جديد
                </a>
            </div>
            <div class="card-body">
                <?php if($group->enrollments->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>اسم الطالب</th>
                                <th>تاريخ التسجيل</th>
                                <th>نسبة الحضور</th>
                                <th>متوسط الدرجات</th>
                                <th>الحالة</th>
                                <th>الإجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $group->enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if($enrollment->student): ?>
                                        <a href="<?php echo e(route('admin.students.show', $enrollment->student_id)); ?>">
                                            <?php echo e($enrollment->student->name); ?>

                                        </a>
                                    <?php else: ?>
                                        طالب <?php echo e($enrollment->student_id); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($enrollment->enrollment_date ? $enrollment->enrollment_date->format('Y-m-d') : 'غير محدد'); ?></td>
                                <td>
                                    <?php
                                        $attendanceCount = $enrollment->student ? $enrollment->student->attendance()->where('group_id', $group->id)->count() : 0;
                                        $presentCount = $enrollment->student ? $enrollment->student->attendance()->where('group_id', $group->id)->where('status', 'present')->count() : 0;
                                        $attendanceRate = $attendanceCount > 0 ? round(($presentCount / $attendanceCount) * 100) : 0;
                                    ?>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar <?php echo e($attendanceRate >= 75 ? 'bg-success' : ($attendanceRate >= 50 ? 'bg-warning' : 'bg-danger')); ?>" 
                                             role="progressbar" style="width: <?php echo e($attendanceRate); ?>%;" 
                                             aria-valuenow="<?php echo e($attendanceRate); ?>" aria-valuemin="0" aria-valuemax="100">
                                            <?php echo e($attendanceRate); ?>%
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <?php
                                        $grades = $enrollment->student ? $enrollment->student->grades()->where('group_id', $group->id)->get() : collect([]);
                                        $avgScore = $grades->count() > 0 ? round($grades->avg('grade')) : 0;
                                    ?>
                                    <span class="badge <?php echo e($avgScore >= 90 ? 'bg-success' : ($avgScore >= 70 ? 'bg-info' : ($avgScore >= 50 ? 'bg-warning' : 'bg-danger'))); ?>">
                                        <?php echo e($avgScore); ?>

                                    </span>
                                </td>
                                <td>
                                    <?php if($enrollment->status == 'active'): ?>
                                        <span class="badge bg-success">نشط</span>
                                    <?php elseif($enrollment->status == 'completed'): ?>
                                        <span class="badge bg-info">مكتمل</span>
                                    <?php elseif($enrollment->status == 'dropped'): ?>
                                        <span class="badge bg-danger">منسحب</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($enrollment->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.students.show', $enrollment->student_id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.enrollments.edit', $enrollment->id)); ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#deleteEnrollmentModal<?php echo e($enrollment->id); ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    
                                    <!-- Delete Enrollment Modal -->
                                    <div class="modal fade" id="deleteEnrollmentModal<?php echo e($enrollment->id); ?>" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">تأكيد إلغاء التسجيل</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
                                                </div>
                                                <div class="modal-body">
                                                    هل أنت متأكد من رغبتك في إلغاء تسجيل الطالب "<?php echo e($enrollment->student->name ?? ''); ?>" من هذه الحلقة؟
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                                                    <form action="<?php echo e(route('admin.enrollments.destroy', $enrollment->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-danger">تأكيد الإلغاء</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    لا يوجد طلاب مسجلين في هذه الحلقة حتى الآن.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title">إحصائيات الحلقة</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6 mb-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">الطلاب</h6>
                                <p class="card-text display-6"><?php echo e($group->enrollments->count()); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card bg-success text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">نسبة الحضور</h6>
                                <p class="card-text display-6">
                                    <?php
                                        $attendanceCount = \App\Models\Attendance::where('group_id', $group->id)->count();
                                        $presentCount = \App\Models\Attendance::where('group_id', $group->id)->where('status', 'present')->count();
                                        $attendanceRate = $attendanceCount > 0 ? round(($presentCount / $attendanceCount) * 100) : 0;
                                    ?>
                                    <?php echo e($attendanceRate); ?>%
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card bg-info text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">التقييمات</h6>
                                <p class="card-text display-6"><?php echo e(\App\Models\Grade::where('group_id', $group->id)->count()); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6 mb-3">
                        <div class="card bg-warning text-white">
                            <div class="card-body text-center">
                                <h6 class="card-title">متوسط الدرجات</h6>
                                <p class="card-text display-6">
                                    <?php
                                        $grades = \App\Models\Grade::where('group_id', $group->id)->get();
                                        $avgScore = $grades->count() > 0 ? round($grades->avg('grade')) : 0;
                                    ?>
                                    <?php echo e($avgScore); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title">الحضور الأخير</h5>
                <a href="<?php echo e(route('admin.attendance.create', ['group_id' => $group->id])); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> تسجيل الحضور
                </a>
            </div>
            <div class="card-body">
                <?php
                    $recentAttendance = \App\Models\Attendance::where('group_id', $group->id)
                        ->orderBy('date', 'desc')
                        ->orderBy('created_at', 'desc')
                        ->take(5)
                        ->get()
                        ->groupBy('date');
                ?>

                <?php if($recentAttendance->count() > 0): ?>
                    <?php $__currentLoopData = $recentAttendance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $attendances): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-3">
                        <div class="card-header bg-light">
                            <h6 class="mb-0"><?php echo e(\Carbon\Carbon::parse($date)->format('Y-m-d')); ?></h6>
                        </div>
                        <div class="card-body p-0">
                            <div class="list-group list-group-flush">
                                <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="list-group-item d-flex justify-content-between align-items-center">
                                    <div>
                                        <?php if($attendance->student): ?>
                                            <a href="<?php echo e(route('admin.students.show', $attendance->student_id)); ?>">
                                                <?php echo e($attendance->student->name); ?>

                                            </a>
                                        <?php else: ?>
                                            طالب <?php echo e($attendance->student_id); ?>

                                        <?php endif; ?>
                                    </div>
                                    <div>
                                        <?php if($attendance->status == 'present'): ?>
                                            <span class="badge bg-success">حاضر</span>
                                        <?php elseif($attendance->status == 'absent'): ?>
                                            <span class="badge bg-danger">غائب</span>
                                        <?php elseif($attendance->status == 'late'): ?>
                                            <span class="badge bg-warning">متأخر</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary"><?php echo e($attendance->status); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-end mt-3">
                        <a href="<?php echo e(route('admin.attendance.index', ['group_id' => $group->id])); ?>" class="btn btn-sm btn-outline-primary">
                            عرض سجل الحضور الكامل
                        </a>
                    </div>
                <?php else: ?>
                <div class="alert alert-info">
                    لا يوجد سجل حضور لهذه الحلقة حتى الآن.
                </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title">أحدث التقييمات</h5>
                <a href="<?php echo e(route('admin.grades.create', ['group_id' => $group->id])); ?>" class="btn btn-sm btn-primary">
                    <i class="fas fa-plus-circle me-1"></i> إضافة تقييم
                </a>
            </div>
            <div class="card-body">
                <?php
                    $recentGrades = \App\Models\Grade::where('group_id', $group->id)
                        ->latest()
                        ->take(5)
                        ->get();
                ?>

                <?php if($recentGrades->count() > 0): ?>
                <div class="list-group">
                    <?php $__currentLoopData = $recentGrades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group-item">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">
                                <a href="<?php echo e(route('admin.students.show', $grade->student_id)); ?>">
                                    <?php echo e($grade->student->name); ?>

                                </a>
                            </h6>
                            <small><?php echo e($grade->date ? $grade->date->format('Y-m-d') : ''); ?></small>
                        </div>
                        <div class="d-flex justify-content-between align-items-center">
                            <p class="mb-1"><?php echo e(Str::limit($grade->notes, 50) ?? 'لا توجد ملاحظات'); ?></p>
                            <span class="badge <?php echo e($grade->grade >= 90 ? 'bg-success' : ($grade->grade >= 70 ? 'bg-info' : ($grade->grade >= 50 ? 'bg-warning' : 'bg-danger'))); ?>">
                                <?php echo e($grade->grade); ?>

                            </span>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="d-flex justify-content-end mt-3">
                    <a href="<?php echo e(route('admin.grades.index', ['group_id' => $group->id])); ?>" class="btn btn-sm btn-outline-primary">
                        عرض جميع التقييمات
                    </a>
                </div>
                <?php else: ?>
                <div class="alert alert-info">
                    لا توجد تقييمات لهذه الحلقة حتى الآن.
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/admin/groups/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'تعديل سجل الحضور'); ?>

<?php $__env->startSection('actions'); ?>
<div class="btn-group" role="group">
    <a href="<?php echo e(route('admin.attendance.index')); ?>" class="btn btn-sm btn-secondary">
        <i class="fas fa-arrow-right me-1"></i> العودة إلى سجل الحضور
    </a>
    <?php if($attendance->group): ?>
    <a href="<?php echo e(route('admin.groups.show', $attendance->group_id)); ?>" class="btn btn-sm btn-secondary">
        <i class="fas fa-arrow-right me-1"></i> العودة إلى الحلقة
    </a>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5 class="card-title">تعديل سجل الحضور</h5>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.attendance.update', $attendance->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            
            <div class="row mb-3">
                <div class="col-md-4">
                    <label for="student_name" class="form-label">الطالب</label>
                    <input type="text" class="form-control" id="student_name" value="<?php echo e($attendance->student->name); ?> " readonly>
                    <input type="hidden" name="student_id" value="<?php echo e($attendance->student_id); ?>">
                </div>
                
                <div class="col-md-4">
                    <label for="group_name" class="form-label">الحلقة</label>
                    <input type="text" class="form-control" id="group_name" value="<?php echo e($attendance->group->name); ?>" readonly>
                    <input type="hidden" name="group_id" value="<?php echo e($attendance->group_id); ?>">
                </div>
                
                <div class="col-md-4">
                    <label for="date" class="form-label">تاريخ الحضور <span class="text-danger">*</span></label>
                    <input type="date" class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date" name="date" value="<?php echo e(old('date', $attendance->date->format('Y-m-d'))); ?>" required>
                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="status" class="form-label">حالة الحضور <span class="text-danger">*</span></label>
                    <div class="btn-group w-100" role="group">
                        <input type="radio" class="btn-check" name="status" id="status_present" value="present" <?php echo e(old('status', $attendance->status) == 'present' ? 'checked' : ''); ?> autocomplete="off">
                        <label class="btn btn-outline-success" for="status_present">حاضر</label>
                        
                        <input type="radio" class="btn-check" name="status" id="status_late" value="late" <?php echo e(old('status', $attendance->status) == 'late' ? 'checked' : ''); ?> autocomplete="off">
                        <label class="btn btn-outline-warning" for="status_late">متأخر</label>
                        
                        <input type="radio" class="btn-check" name="status" id="status_excused" value="excused" <?php echo e(old('status', $attendance->status) == 'excused' ? 'checked' : ''); ?> autocomplete="off">
                        <label class="btn btn-outline-info" for="status_excused">معذور</label>
                        
                        <input type="radio" class="btn-check" name="status" id="status_absent" value="absent" <?php echo e(old('status', $attendance->status) == 'absent' ? 'checked' : ''); ?> autocomplete="off">
                        <label class="btn btn-outline-danger" for="status_absent">غائب</label>
                    </div>
                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="col-md-6">
                    <label for="teacher_id" class="form-label">المعلم المسؤول <span class="text-danger">*</span></label>
                    <select class="form-select <?php $__errorArgs = ['teacher_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="teacher_id" name="teacher_id" required>
                        <option value="">-- اختر المعلم --</option>
                        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($teacher->id); ?>" <?php echo e(old('teacher_id', $attendance->teacher_id) == $teacher->id ? 'selected' : ''); ?>><?php echo e($teacher->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['teacher_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            
            <div class="mb-3">
                <label for="notes" class="form-label">ملاحظات</label>
                <textarea class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="notes" name="notes" rows="3"><?php echo e(old('notes', $attendance->notes)); ?></textarea>
                <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="d-flex justify-content-between">
                <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">
                    <i class="fas fa-trash me-1"></i> حذف السجل
                </button>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-1"></i> حفظ التغييرات
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">تأكيد الحذف</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="إغلاق"></button>
            </div>
            <div class="modal-body">
                هل أنت متأكد من رغبتك في حذف سجل حضور الطالب "<?php echo e($attendance->student->name); ?> " بتاريخ <?php echo e($attendance->date->format('Y-m-d')); ?>؟
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">إلغاء</button>
                <form action="<?php echo e(route('admin.attendance.destroy', $attendance->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">حذف</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\admin1\CascadeProjects\QuranSystem\QuranSystem\resources\views/admin/attendance/edit.blade.php ENDPATH**/ ?>